#include "esp_camera.h"
#include <WiFi.h>
#include "board_config.h"
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include "Arduino.h"

#define CAMERA_MODEL_WROVER_KIT
#include "camera_pins.h"

void startCameraServer();

const char* SSID     = "WASAAA 6447";
const char* PASSWORD = "51G7@w33";

const char* MQTT_BROKER   = "192.168.137.177";
const int   MQTT_PORT     = 1883;
const char* TOPIC_DATOS   = "tractor/datos";
const char* TOPIC_CONTROL = "tractor/control";
const char* CLIENT_ID     = "ESP32_CAM_Tractor";

const unsigned long MQTT_INTERVAL = 200;

#define STM32_RX_PIN  16
#define STM32_TX_PIN  17
#define STM32_BAUD    115200

WiFiClient    wifiClient;
PubSubClient  mqttClient(wifiClient);
camera_config_t camConfig;

volatile int    stm_rpm   = 0;
volatile float stm_speed = 0.0f;
volatile int    stm_gear  = 0;
volatile bool   stm_fresh = false;

#define BUF_SIZE 32
char    rxBuf[BUF_SIZE];
uint8_t rxIdx = 0;

unsigned long lastMqttSend = 0;

void parse_stm32_frame(char* frame)
{
    char* token = strtok(frame, ",");
    if (!token) return;
    int rpm = atoi(token);

    token = strtok(NULL, ",");
    if (!token) return;
    int speed = atoi(token);

    token = strtok(NULL, ",");
    if (!token) return;
    int gear = atoi(token);

    stm_rpm   = rpm;
    stm_speed = (float)speed;
    stm_gear  = gear;
    stm_fresh = true;

    Serial.printf("[STM32] RPM=%d | Vel=%d km/h | Marcha=%d\n", rpm, speed, gear);
}

void leer_stm32()
{
    while (Serial2.available())
    {
        char c = (char)Serial2.read();

        if (c == '\n')
        {
            if (rxIdx > 0 && rxBuf[rxIdx - 1] == '\r') rxIdx--;
            rxBuf[rxIdx] = '\0';
            if (rxIdx > 0) parse_stm32_frame(rxBuf);
            rxIdx = 0;
        }
        else if (rxIdx < BUF_SIZE - 1)
        {
            rxBuf[rxIdx++] = c;
        }
        else
        {
            rxIdx = 0;
        }
    }
}

void mqttCallback(char* topic, byte* payload, unsigned int length)
{
    String msg;
    for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];
    Serial.printf("[MQTT] Comando recibido en '%s': %s\n", topic, msg.c_str());

    StaticJsonDocument<128> doc;
    DeserializationError err = deserializeJson(doc, msg);
    if (err) {
        Serial.printf("[MQTT] JSON inválido: %s\n", err.c_str());
        return;
    }

    String cmd = doc["cmd"] | "neutro";

    if (cmd == "acelerar") {
        Serial.println("[CMD] Acelerar");
    } else if (cmd == "frenar") {
        Serial.println("[CMD] Frenar");
    } else if (cmd == "neutro") {
        Serial.println("[CMD] Neutro");
    } else {
        Serial.printf("[CMD] Comando desconocido: %s\n", cmd.c_str());
    }
}

void reconectarMQTT()
{
    while (!mqttClient.connected())
    {
        Serial.print("[MQTT] Conectando...");
        if (mqttClient.connect(CLIENT_ID))
        {
            Serial.println(" OK");
            mqttClient.subscribe(TOPIC_CONTROL);
            Serial.printf("[MQTT] Suscrito a '%s'\n", TOPIC_CONTROL);
        }
        else
        {
            Serial.printf(" Fallo rc=%d — reintentando en 3s\n", mqttClient.state());
            delay(3000);
        }
    }
}

void enviarTelemetria()
{
    StaticJsonDocument<128> doc;
    doc["rpm"]   = stm_rpm;
    doc["speed"] = stm_speed;
    doc["gear"]  = stm_gear;

    char buffer[128];
    serializeJson(doc, buffer);

    mqttClient.publish(TOPIC_DATOS, buffer);

    Serial.printf("[MQTT→RPi] RPM=%d | Vel=%.1f km/h | Marcha=%d\n", stm_rpm, stm_speed, stm_gear);

    stm_fresh = false;
}

void camera_init()
{
    camConfig.ledc_channel = LEDC_CHANNEL_0;
    camConfig.ledc_timer   = LEDC_TIMER_0;
    camConfig.pin_d0       = Y2_GPIO_NUM;
    camConfig.pin_d1       = Y3_GPIO_NUM;
    camConfig.pin_d2       = Y4_GPIO_NUM;
    camConfig.pin_d3       = Y5_GPIO_NUM;
    camConfig.pin_d4       = Y6_GPIO_NUM;
    camConfig.pin_d5       = Y7_GPIO_NUM;
    camConfig.pin_d6       = Y8_GPIO_NUM;
    camConfig.pin_d7       = Y9_GPIO_NUM;
    camConfig.pin_xclk     = XCLK_GPIO_NUM;
    camConfig.pin_pclk     = PCLK_GPIO_NUM;
    camConfig.pin_vsync    = VSYNC_GPIO_NUM;
    camConfig.pin_href     = HREF_GPIO_NUM;
    camConfig.pin_sccb_sda = SIOD_GPIO_NUM;
    camConfig.pin_sccb_scl = SIOC_GPIO_NUM;
    camConfig.pin_pwdn     = PWDN_GPIO_NUM;
    camConfig.pin_reset    = RESET_GPIO_NUM;
    camConfig.xclk_freq_hz = 10000000;
    camConfig.pixel_format = PIXFORMAT_JPEG;
    camConfig.frame_size   = FRAMESIZE_VGA;
    camConfig.grab_mode    = CAMERA_GRAB_WHEN_EMPTY;
    camConfig.fb_location  = CAMERA_FB_IN_PSRAM;
    camConfig.jpeg_quality = 10;
    camConfig.fb_count     = 2;

    esp_err_t err = esp_camera_init(&camConfig);
    if (err != ESP_OK) {
        if (err == ESP_ERR_NOT_SUPPORTED) {
            camConfig.pixel_format = PIXFORMAT_RGB565;
            err = esp_camera_init(&camConfig);
        }
        if (err != ESP_OK) {
            Serial.printf("[CAM] Init falló: 0x%x\n", err);
            return;
        }
    }

    sensor_t* s   = esp_camera_sensor_get();
    uint16_t  pid = s->id.PID;

    if      (pid == OV2640_PID) { s->set_hmirror(s, 1); s->set_vflip(s, 1); }
    else if (pid == OV3660_PID) { s->set_hmirror(s, 1); s->set_vflip(s, 0); }
    else if (pid == GC2145_PID) { s->set_hmirror(s, 0); delay(500); s->set_vflip(s, 0); }
    else if (pid == GC0308_PID) { s->set_hmirror(s, 0); delay(500); s->set_vflip(s, 0); }
    else                        { s->set_hmirror(s, 1); s->set_vflip(s, 0); }

    s->set_brightness(s, 1);
    s->set_saturation(s, 0);
    s->set_ae_level(s, -3);
    s->set_exposure_ctrl(s, 1);
    s->set_awb_gain(s, 1);
    s->set_whitebal(s, 1);

    Serial.println("[CAM] Inicializada OK");
}

void setup()
{
    Serial.begin(115200);

    pinMode(26, OUTPUT); pinMode(27, OUTPUT);
    digitalWrite(26, LOW); digitalWrite(27, LOW);
    delay(200);
    pinMode(26, INPUT); pinMode(27, INPUT);
    delay(200);

    Serial.setDebugOutput(true);
    Serial.println();
    Serial.println("========================================");
    Serial.println("  Tractor ESP32-CAM  —  Iniciando");
    Serial.println("========================================");

    Serial2.begin(STM32_BAUD, SERIAL_8N1, STM32_RX_PIN, STM32_TX_PIN);
    Serial.printf("[UART2] Escuchando STM32 en GPIO%d a %d baud\n", STM32_RX_PIN, STM32_BAUD);

    camera_init();

    WiFi.begin(SSID, PASSWORD);
    WiFi.setSleep(false);
    Serial.print("[WiFi] Conectando");
    while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
    Serial.printf("\n[WiFi] IP: %s\n", WiFi.localIP().toString().c_str());

    startCameraServer();

    mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
    mqttClient.setCallback(mqttCallback);
    mqttClient.setBufferSize(256);
    reconectarMQTT();

    Serial.println("========================================");
    Serial.printf("  Stream : http://%s:81/stream\n", WiFi.localIP().toString().c_str());
    Serial.printf("  MQTT   : %s:%d\n", MQTT_BROKER, MQTT_PORT);
    Serial.printf("  Publica: %s\n", TOPIC_DATOS);
    Serial.printf("  Escucha: %s\n", TOPIC_CONTROL);
    Serial.println("  Todo listo!");
    Serial.println("========================================");
}

void loop()
{
    if (!mqttClient.connected()) reconectarMQTT();
    mqttClient.loop();

    leer_stm32();

    unsigned long ahora = millis();
    if (ahora - lastMqttSend >= MQTT_INTERVAL)
    {
        lastMqttSend = ahora;
        enviarTelemetria();
    }
}
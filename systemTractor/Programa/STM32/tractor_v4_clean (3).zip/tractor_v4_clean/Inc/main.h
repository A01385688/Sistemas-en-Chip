#ifndef INC_MAIN_H_
#define INC_MAIN_H_

/* ============================================================
 * main.h  —  STM32F103C8  Blue Pill  @  64 MHz
 * Avance 4 — base: Avance 2
 *
 * ─────────────────────────────────────────────────────────────
 * MAPA DE PINES
 * ─────────────────────────────────────────────────────────────
 *  LCD I2C  : PB6 (SCL)  PB7 (SDA)   PCF8574, dir. 0x27
 *  POT      : PA0  → ADC1_CH0   (aceleración 0-100%)
 *  BRAKE    : PA1  → entrada pull-up (botón a GND)
 *  USART1   : PA9 (TX)  PA10 (RX)   115200-8N1  ← ESP32
 *  TIM2     : tick modelo cada 40 ms (PSC=6399, ARR=399)
 *  LEDs     : PC13 activo-bajo  PC14 activo-bajo
 *             PB10 activo-alto  PB11 activo-alto
 *
 *  MOTORES DELANTEROS (L298N #1)  sin reductor 1:1
 *    IN1=PA8  IN2=PB3  IN3=PA11  IN4=PA12
 *    ENA=PB4  ENB=PB5  (PWM software TIM2 ISR)
 *
 *  MOTORES TRASEROS (L298N #2)  reductor 6:20
 *    IN1=PA2  IN2=PA3  IN3=PA4  IN4=PA5
 *    ENA=PA6  ENB=PA7  (PWM software TIM2 ISR)
 *
 *  SERVOS (TIM3/TIM4 @ 50 Hz)  — solo Modo Instrucciones
 *    Servo1=PB0 (TIM3_CH3)
 *    Servo2=PB1 (TIM3_CH4)
 *    Servo3=PB9 (TIM4_CH4)
 *
 * ─────────────────────────────────────────────────────────────
 * PROTOCOLO USART (115200-8N1, terminador '\n')
 *
 *  Recibe (ESP32 → STM):
 *    "MODE:M\n"   → Modo Manual (default al arrancar)
 *    "MODE:I\n"   → Modo Instrucciones
 *    "A:XXX\n"    → aceleración 0-100%   (solo Modo I)
 *    "B:X\n"      → freno 0/1            (solo Modo I)
 *    "S1:XXX\n"   → Servo1 0-180°        (solo Modo I)
 *    "S2:XXX\n"   → Servo2 0-180°        (solo Modo I)
 *    "S3:XXX\n"   → Servo3 0-180°        (solo Modo I)
 *
 *  Envía cada 40 ms (STM → ESP32):
 *    {"m":X,"a":XXX,"b":X,"r":XXXXX,"v":XXX,"g":X,
 *     "pf":XXX,"pt":XXX,"s1":XXX,"s2":XXX,"s3":XXX}\n
 *
 *    m=modo(0/1) a=accel% b=freno r=RPM v=km/h g=marcha
 *    pf=PWM_delantero% pt=PWM_trasero%
 *    s1/s2/s3=ángulo servo°
 *
 * ─────────────────────────────────────────────────────────────
 * LÓGICA DE MOTORES
 *  pwm_base = vspeed * 100 / VSPEED_MAX_KMH
 *  Delantero: pwm_fwd  = pwm_base               (1:1)
 *  Trasero:   pwm_rear = min(100, pwm_base*20/6) (reductor)
 *
 * FRENO SUAVE
 *  Cada tick se resta BRAKE_RAMP_STEP a la aceleración virtual.
 *  Ajustar en este header para cambiar la dureza del frenado.
 *
 * ─────────────────────────────────────────────────────────────
 * PARÁMETROS AJUSTABLES
 * ============================================================ */

/* Velocidad máxima (km/h) — clampea la salida del modelo */
#define VSPEED_MAX_KMH      120U

/* Paso de reducción de aceleración por tick al frenar (0.5-5.0)
 * 2.0 → frena de 100% a 2% en ~2 s                           */
#define BRAKE_RAMP_STEP     2.0

/* Relación de reducción trasera: motor necesita 20/6 más RPM */
#define REAR_GEAR_RATIO     (20.0f / 6.0f)

/* Periodo PWM software en ticks de TIM2 (1 tick = 1 ms @ 1 kHz)
 * MOTOR_PWM_PERIOD = 10 → 10 ms → 100 Hz
 * Resolución: 10% por paso (suficiente con duty mínimo)         */
#define MOTOR_PWM_PERIOD    10U

/* Duty mínimo para vencer inercia del L298N + motor DC (0-MOTOR_PWM_PERIOD).
 * Este valor está en TICKS, no en %.
 * Con MOTOR_PWM_PERIOD=10: 8 ticks = 80%, 7 ticks = 70%, etc.
 * Ajustar si los motores no arrancan (subir) o van muy rápido (bajar). */
#define MOTOR_DUTY_MIN_TICKS  8U

/* Servo: rango CCR (ARR=999, PSC=1279 → 1 cnt ≈ 20 µs)
 * 1000 µs = CCR 50 | 1500 µs = CCR 75 | 2000 µs = CCR 100   */
#define SERVO_MIN_CCR       50U
#define SERVO_MID_CCR       75U
#define SERVO_MAX_CCR       100U

/* ─── Dirección I2C del módulo PCF8574 ─── */
#define LCD_I2C_ADDR        0x27U

/* ─── Prototipos comunes ─── */
#include <stdint.h>
#include "stm32f1xx.h"

void rcc_init_64MHz(void);
void delay_us(uint16_t us);
void delay_ms(uint16_t ms);
void usart1_init(void);
void usart1_send_char(char c);
void usart1_send_str(const char *s);

#endif /* INC_MAIN_H_ */

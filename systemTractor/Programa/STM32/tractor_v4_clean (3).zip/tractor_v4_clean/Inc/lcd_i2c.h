#ifndef INC_LCD_I2C_H_
#define INC_LCD_I2C_H_

/* ============================================================
 * lcd_i2c.h  —  LCD 16×2 vía PCF8574  (I2C1: PB6=SCL PB7=SDA)
 *
 * Mapa de bits del PCF8574 al HD44780:
 *   P0=RS  P1=RW  P2=EN  P3=BL  P4=D4  P5=D5  P6=D6  P7=D7
 * ============================================================ */

#include <stdint.h>

#define LCD_Clear()       LCD_Cmd(0x01U)
#define LCD_Home()        LCD_Cmd(0x02U)
#define LCD_DisplayON()   LCD_Cmd(0x0CU)
#define LCD_DisplayOFF()  LCD_Cmd(0x08U)
#define LCD_CursorON()    LCD_Cmd(0x0EU)
#define LCD_CursorBlink() LCD_Cmd(0x0FU)

void LCD_Init(void);
void LCD_Cmd(uint8_t cmd);
void LCD_PutChar(char c);
void LCD_SetCursor(uint8_t row, uint8_t col);  /* base 1 */
void LCD_PutStr(const char *s);
void LCD_PutUInt(uint32_t val, uint8_t width); /* relleno izq. con espacios */

#endif /* INC_LCD_I2C_H_ */

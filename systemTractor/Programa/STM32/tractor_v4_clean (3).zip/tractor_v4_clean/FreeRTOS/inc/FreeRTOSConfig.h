#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

/* ============================================================
 * FreeRTOSConfig.h — STM32F103C8 Blue Pill @ 64 MHz
 * 20KB RAM / 64KB Flash
 * FreeRTOS V11 — Cortex-M3 port
 * ============================================================ */

/* Incluir CMSIS aquí para que configASSERT pueda usar
 * __disable_irq() y para que el port vea los tipos de ARM */
#include "stm32f1xx.h"

/* ── Clock ── */
#define configCPU_CLOCK_HZ              ( 64000000UL )
#define configSYSTICK_CLOCK_HZ          configCPU_CLOCK_HZ

/* ── Tick: 1 kHz = 1 ms por tick ──
 * FreeRTOS V11 requiere configTICK_TYPE_WIDTH_IN_BITS.
 * TICK_TYPE_WIDTH_32_BITS → TickType_t = uint32_t              */
#define configTICK_RATE_HZ              ( 1000 )
#define configTICK_TYPE_WIDTH_IN_BITS   TICK_TYPE_WIDTH_32_BITS

/* ── Prioridades de tareas ── */
#define configMAX_PRIORITIES            ( 5 )
#define configMINIMAL_STACK_SIZE        ( 128 )

/* ── Heap: 8 KB ── */
#define configTOTAL_HEAP_SIZE           ( 8 * 1024 )

/* ── Misc ── */
#define configMAX_TASK_NAME_LEN         ( 8 )
#define configUSE_PREEMPTION            1
#define configUSE_IDLE_HOOK             0
#define configUSE_TICK_HOOK             0
#define configUSE_MUTEXES               1
#define configUSE_RECURSIVE_MUTEXES     0
#define configUSE_COUNTING_SEMAPHORES   0
#define configQUEUE_REGISTRY_SIZE       0
#define configUSE_PORT_OPTIMISED_TASK_SELECTION 1

/* ── Sin estadísticas (ahorrar RAM/Flash) ── */
#define configUSE_TRACE_FACILITY            0
#define configUSE_STATS_FORMATTING_FUNCTIONS 0
#define configGENERATE_RUN_TIME_STATS       0

/* ── Sin software timers ── */
#define configUSE_TIMERS                0

/* ── Sin co-routines ── */
#define configUSE_CO_ROUTINES           0

/* ── Aserción: loop infinito con IRQ deshabilitadas ──
 * __disable_irq() está disponible via stm32f1xx.h → core_cm3.h  */
#ifdef DEBUG
  #define configASSERT( x )  \
      do { if( ( x ) == 0 ) { __disable_irq(); for(;;); } } while(0)
#else
  #define configASSERT( x )
#endif

/* ── Prioridades NVIC (STM32F1: 4 bits, 0=más alta, 15=más baja)
 *
 *  KERNEL (SysTick, PendSV): prioridad 15 (la más baja)
 *  MAX_SYSCALL: prioridad 5 — interrupciones con prioridad numérica
 *    >= 5 pueden usar funciones FreeRTOS *FromISR().
 *  TIM2 (PWM): prioridad 4 → por encima del umbral, NO usa FromISR.
 * ── */
#define configLIBRARY_LOWEST_INTERRUPT_PRIORITY      15
#define configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY  5

#define configKERNEL_INTERRUPT_PRIORITY \
    ( configLIBRARY_LOWEST_INTERRUPT_PRIORITY << 4 )

#define configMAX_SYSCALL_INTERRUPT_PRIORITY \
    ( configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY << 4 )

/* ── Mapeo de handlers al vector table de CMSIS ── */
#define vPortSVCHandler     SVC_Handler
#define xPortPendSVHandler  PendSV_Handler
#define xPortSysTickHandler SysTick_Handler

/* ── API habilitada ── */
#define INCLUDE_vTaskDelay                  1
#define INCLUDE_vTaskDelayUntil             1
#define INCLUDE_uxTaskGetStackHighWaterMark 1
#define INCLUDE_vTaskDelete                 0
#define INCLUDE_vTaskSuspend                0
#define INCLUDE_xTaskGetCurrentTaskHandle   0

#endif /* FREERTOS_CONFIG_H */

/* ============================================================
 * lcd_i2c.c  —  LCD HD44780 vía PCF8574  usando I2C1 hardware
 *
 * Pines  : PB6 = SCL   PB7 = SDA   (I2C1, AF open-drain)
 * APB1   : 32 MHz  →  I2C a 100 kHz estándar
 *
 * Mapa de bits PCF8574 → HD44780
 *   bit0=RS  bit1=RW  bit2=EN  bit3=BL  bit4-7=D4-D7
 * ============================================================ */

#include "main.h"
#include "lcd_i2c.h"

#define ADDR_W   ((LCD_I2C_ADDR) << 1)   /* dirección con W=0 */
#define BL_BIT   (1U << 3)               /* backlight siempre encendido */

/* ============================================================
 * i2c1_init
 *   APB1 = 32 MHz
 *   CCR  = 32e6 / (2 * 100e3) = 160
 *   TRISE= 32 + 1 = 33
 * ============================================================ */
static void i2c1_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

    /* PB6 (SCL) y PB7 (SDA): AF open-drain 50 MHz
     * CRL bits [27:24]=PB6, [31:28]=PB7
     * CNF=11 MODE=11 → 0xF */
    GPIOB->CRL &= ~((0xFUL << 24) | (0xFUL << 28));
    GPIOB->CRL |=  ((0xFUL << 24) | (0xFUL << 28));

    /* Reset del periférico I2C */
    I2C1->CR1 = I2C_CR1_SWRST;
    I2C1->CR1 = 0U;

    I2C1->CR2   = 32U;    /* FREQ = 32 (MHz de APB1) */
    I2C1->CCR   = 160U;   /* 100 kHz */
    I2C1->TRISE = 33U;
    I2C1->CR1   = I2C_CR1_PE;
}

/* Espera con timeout pasivo */
static void i2c_wait_flag(volatile uint32_t *reg, uint32_t flag)
{
    uint32_t t = 1000000UL;
    while (!(*reg & flag) && --t);
}

/* ============================================================
 * i2c1_write_byte — envía un byte al PCF8574
 * ============================================================ */
static void i2c1_write_byte(uint8_t data)
{
    /* START */
    I2C1->CR1 |= I2C_CR1_START;
    i2c_wait_flag(&I2C1->SR1, I2C_SR1_SB);

    /* Dirección + W */
    I2C1->DR = ADDR_W;
    i2c_wait_flag(&I2C1->SR1, I2C_SR1_ADDR);
    (void)I2C1->SR2;   /* limpiar flag ADDR leyendo SR2 */

    /* Dato */
    I2C1->DR = data;
    i2c_wait_flag(&I2C1->SR1, I2C_SR1_BTF);

    /* STOP */
    I2C1->CR1 |= I2C_CR1_STOP;
}

/* ============================================================
 * Envío de nibble con pulso EN
 * ============================================================ */
static void lcd_nibble(uint8_t nibble, uint8_t rs)
{
    /* D7-D4 en bits [7:4], RS en bit0, BL en bit3 */
    uint8_t base = (uint8_t)((nibble << 4) | BL_BIT | (rs ? 1U : 0U));
    i2c1_write_byte(base | (1U << 2));  /* EN=1 */
    delay_us(2);
    i2c1_write_byte(base & ~(1U << 2)); /* EN=0 */
    delay_us(50);
}

/* ============================================================
 * Byte completo en 4-bit
 * ============================================================ */
static void lcd_byte(uint8_t val, uint8_t rs)
{
    lcd_nibble((val >> 4) & 0x0FU, rs);
    lcd_nibble(val & 0x0FU,        rs);
}

/* ============================================================
 * API pública
 * ============================================================ */
void LCD_Cmd(uint8_t cmd)
{
    lcd_byte(cmd, 0);
    if (cmd == 0x01U || cmd == 0x02U)
        delay_ms(2);
}

void LCD_PutChar(char c)
{
    lcd_byte((uint8_t)c, 1);
}

void LCD_SetCursor(uint8_t row, uint8_t col)
{
    /* HD44780: línea 1 offset 0x00, línea 2 offset 0x40 */
    static const uint8_t off[2] = { 0x00U, 0x40U };
    LCD_Cmd(0x80U | (off[(row - 1U) & 1U] + (col - 1U)));
}

void LCD_PutStr(const char *s)
{
    while (*s) LCD_PutChar(*s++);
}

void LCD_PutUInt(uint32_t val, uint8_t width)
{
    char    buf[10];
    uint8_t n = 0;
    if (val == 0U) { buf[n++] = '0'; }
    else { uint32_t v = val; while (v) { buf[n++] = (char)('0' + v % 10U); v /= 10U; } }
    /* relleno izquierdo con espacios */
    for (uint8_t s = n; s < width; s++) LCD_PutChar(' ');
    /* dígitos en orden correcto */
    for (int8_t j = (int8_t)(n - 1); j >= 0; j--) LCD_PutChar(buf[j]);
}

/* ============================================================
 * LCD_Init — secuencia HD44780 modo 4-bit
 * ============================================================ */
void LCD_Init(void)
{
    i2c1_init();
    delay_ms(50);                        /* tiempo de power-on del LCD */

    /* Reset por software (HD44780 fig. 24) */
    lcd_nibble(0x03U, 0); delay_ms(5);
    lcd_nibble(0x03U, 0); delay_us(200);
    lcd_nibble(0x03U, 0); delay_us(200);
    lcd_nibble(0x02U, 0); delay_us(200); /* → modo 4-bit */

    LCD_Cmd(0x28U);  /* 4-bit, 2 líneas, 5×8 */
    LCD_Cmd(0x08U);  /* Display OFF */
    LCD_Cmd(0x01U);  /* Clear */
    LCD_Cmd(0x06U);  /* Entry mode: cursor right */
    LCD_Cmd(0x0CU);  /* Display ON, cursor OFF */
}

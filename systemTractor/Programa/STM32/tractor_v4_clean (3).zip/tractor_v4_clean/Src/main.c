/* ============================================================
 * main.c  —  STM32F103C8  Blue Pill  @  64 MHz
 * Avance 5 — versión ESP32
 *
 * CAMBIOS RESPECTO AL AVANCE 4:
 *  1. Modo Manual:
 *     - Potenciómetro → PWM motores DIRECTO (sin modelo).
 *     - Modelo lee el potenciómetro solo para generar datos
 *       de telemetría (rpm, vspeed, gear). No controla nada físico.
 *     - Botón freno: baja PWM de su valor actual a 0 en máximo
 *       3 segundos (proporcional a la aceleración actual).
 *       BRAKE_STEP_PER_TICK = accel_actual / (3000ms/40ms) = accel/75
 *     - S1 y S3 oscilan automáticamente entre sus límites.
 *       S1: 0–180°  S3: 0–150°
 *
 *  2. Límites de servos:
 *     S1 (cámara pan) : 0–180°
 *     S2 (servo 2)    : 0–180°
 *     S3 (cámara tilt): 0–150°
 *
 *  3. Modo Instrucciones: sin cambios. ESP32 controla todo.
 *
 * NO MODIFICADO: EngTrModel.c/h, lcd_i2c.c/h
 * ============================================================ */

#include "main.h"
#include "lcd_i2c.h"
#include "EngTrModel.h"
#include "rt_nonfinite.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ============================================================
 * TIPOS
 * ============================================================ */
typedef enum { MODE_MANUAL = 0, MODE_INSTRUCCIONES = 1 } OpMode_t;

typedef struct {
    uint16_t rpm;
    uint16_t vspeed;
    uint8_t  gear;
    uint16_t accel_pct;
    uint8_t  brake;
    uint8_t  mode;
    uint8_t  pwm_fwd_pct;
    uint8_t  pwm_rear_pct;
} ModelState_t;

/* ============================================================
 * HANDLES FREERTOS
 * ============================================================ */
static QueueHandle_t     xQueueModel;
static SemaphoreHandle_t xMutexModel;

/* ============================================================
 * ESTADO GLOBAL
 * ============================================================ */
static volatile OpMode_t op_mode       = MODE_MANUAL;
static volatile double   accel_virtual = 2.0;
static volatile uint8_t  brake_cmd     = 0U;
static volatile uint16_t servo1_deg    = 90U;
static volatile uint16_t servo2_deg    = 90U;
static volatile uint16_t servo3_deg    = 75U;   /* centro de 0-150 */

/* PWM motores — escrito por tMotores, leído por ISR TIM2 */
volatile uint8_t pwm_fwd  = 0U;
volatile uint8_t pwm_rear = 0U;

/* ============================================================
 * BUFFER RX USART
 * ============================================================ */
#define RX_BUF_SIZE 32U
static volatile char    rx_buf[RX_BUF_SIZE];
static volatile uint8_t rx_idx = 0U;
static volatile uint8_t rx_rdy = 0U;

/* ============================================================
 * DELAYS (solo durante init, antes del scheduler)
 * ============================================================ */
void delay_us(uint16_t us)
{
    volatile uint32_t n = (uint32_t)us * 10UL;
    while (n--);
}
void delay_ms(uint16_t ms)
{
    for (uint16_t i = 0; i < ms; i++) delay_us(1000U);
}

/* ============================================================
 * RCC — 64 MHz
 * ============================================================ */
void rcc_init_64MHz(void)
{
    FLASH->ACR = (FLASH->ACR & ~FLASH_ACR_LATENCY)
               | FLASH_ACR_LATENCY_2 | FLASH_ACR_PRFTBE;

    RCC->CFGR = (RCC->CFGR
                 & ~(RCC_CFGR_PLLSRC | RCC_CFGR_PLLMULL |
                     RCC_CFGR_HPRE   | RCC_CFGR_PPRE1   | RCC_CFGR_PPRE2))
               | RCC_CFGR_PLLMULL16 | RCC_CFGR_PPRE1_DIV2;

    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));

    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_SW) | RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);
}

/* ============================================================
 * USART1 — PA9=TX  PA10=RX  115200-8N1
 * ============================================================ */
void usart1_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_USART1EN | RCC_APB2ENR_IOPAEN | RCC_APB2ENR_AFIOEN;
    GPIOA->CRH = (GPIOA->CRH & ~(0xFUL<<4)) | (0xBUL<<4);
    GPIOA->CRH = (GPIOA->CRH & ~(0xFUL<<8)) | (0x4UL<<8);
    USART1->BRR = 0x022BU;
    USART1->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_RXNEIE | USART_CR1_UE;
    NVIC_SetPriority(USART1_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY);
    NVIC_EnableIRQ(USART1_IRQn);
}

void usart1_send_char(char c)
{
    while (!(USART1->SR & USART_SR_TXE));
    USART1->DR = (uint8_t)c;
}
void usart1_send_str(const char *s)
{
    while (*s) usart1_send_char(*s++);
}

/* ISR — acumula hasta '\n' o '\r'. Detecta MODE:M/I sin terminador. */
void USART1_IRQHandler(void)
{
    if (!(USART1->SR & USART_SR_RXNE)) return;
    char c = (char)(USART1->DR & 0xFFU);

    if (c == '\n' || c == '\r')
    {
        if (rx_idx > 0U) { rx_buf[rx_idx] = '\0'; rx_idx = 0U; rx_rdy = 1U; }
    }
    else if (rx_idx < RX_BUF_SIZE - 1U)
    {
        rx_buf[rx_idx++] = c;
        /* Dispatch inmediato para MODE:M / MODE:I (6 chars exactos) */
        if (rx_idx == 6U &&
            rx_buf[0]=='M' && rx_buf[1]=='O' && rx_buf[2]=='D' &&
            rx_buf[3]=='E' && rx_buf[4]==':')
        {
            rx_buf[6] = '\0'; rx_idx = 0U; rx_rdy = 1U;
        }
    }
    else { rx_buf[RX_BUF_SIZE-1U] = '\0'; rx_idx = 0U; rx_rdy = 1U; }
}

/* ============================================================
 * TIM2 — PWM software motores @ 1 kHz
 *   PSC=63, ARR=999 → 64MHz/64/1000 = 1 kHz
 *   ENA/ENB delantero: PB4, PB5
 *   ENA/ENB trasero:   PA6, PA7
 *   Prioridad: por encima de MAX_SYSCALL → no llama FromISR
 * ============================================================ */
static void tim2_pwm_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    TIM2->CR1  = 0U;
    TIM2->PSC  = 63U;
    TIM2->ARR  = 999U;
    TIM2->CNT  = 0U;
    TIM2->SR   = 0U;
    TIM2->DIER = TIM_DIER_UIE;
    TIM2->CR1  = TIM_CR1_CEN;
    NVIC_SetPriority(TIM2_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY - 1);
    NVIC_EnableIRQ(TIM2_IRQn);
}

void TIM2_IRQHandler(void)
{
    if (!(TIM2->SR & TIM_SR_UIF)) return;
    TIM2->SR &= ~TIM_SR_UIF;

    static uint8_t ctr = 0U;
    if (++ctr >= MOTOR_PWM_PERIOD) ctr = 0U;

    if (ctr < pwm_fwd)
        GPIOB->BSRR = (1UL<<4)|(1UL<<5);
    else
        GPIOB->BSRR = (1UL<<(4+16))|(1UL<<(5+16));

    if (ctr < pwm_rear)
        GPIOA->BSRR = (1UL<<6)|(1UL<<7);
    else
        GPIOA->BSRR = (1UL<<(6+16))|(1UL<<(7+16));
}

/* ============================================================
 * TIM3 — 50 Hz  Servo1=PB0 (CH3)  Servo2=PB1 (CH4)
 *   Remap parcial: CH1→PB4, CH2→PB5 → libera PA6/PA7 como GPIO
 * ============================================================ */
static void tim3_servo_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;
    RCC->APB2ENR |= RCC_APB2ENR_AFIOEN;

    AFIO->MAPR = (AFIO->MAPR & ~AFIO_MAPR_TIM3_REMAP)
               | AFIO_MAPR_TIM3_REMAP_PARTIALREMAP;

    GPIOB->CRL = (GPIOB->CRL & ~((0xFUL<<0)|(0xFUL<<4)))
               | ((0xBUL<<0)|(0xBUL<<4));

    TIM3->CR1   = 0U;
    TIM3->PSC   = 1279U;
    TIM3->ARR   = 999U;
    TIM3->CCMR2 = (0x6UL<<4)|TIM_CCMR2_OC3PE|(0x6UL<<12)|TIM_CCMR2_OC4PE;
    TIM3->CCER  = TIM_CCER_CC3E|TIM_CCER_CC4E;
    TIM3->CCR3  = SERVO_MID_CCR;
    TIM3->CCR4  = SERVO_MID_CCR;
    TIM3->EGR   = TIM_EGR_UG;
    TIM3->CR1   = TIM_CR1_CEN;

    /* Forzar PA6/PA7 como GPIO output después del init de TIM3 */
    GPIOA->CRL = (GPIOA->CRL & ~((0xFUL<<24)|(0xFUL<<28)))
               | ((0x2UL<<24)|(0x2UL<<28));
}

/* ============================================================
 * TIM4 — 50 Hz  Servo3=PB9 (CH4)
 * ============================================================ */
static void tim4_servo_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
    GPIOB->CRH = (GPIOB->CRH & ~(0xFUL<<4)) | (0xBUL<<4);
    TIM4->CR1   = 0U;
    TIM4->PSC   = 1279U;
    TIM4->ARR   = 999U;
    TIM4->CCMR2 = (0x6UL<<12)|TIM_CCMR2_OC4PE;
    TIM4->CCER |= TIM_CCER_CC4E;
    TIM4->CCR4  = SERVO_MID_CCR;
    TIM4->EGR   = TIM_EGR_UG;
    TIM4->CR1   = TIM_CR1_CEN;
}

/* grados → CCR (ARR=999, CCR 50=1ms, 75=1.5ms, 100=2ms) */
static inline uint32_t deg_to_ccr(uint16_t deg)
{
    return (uint32_t)SERVO_MIN_CCR
         + ((uint32_t)deg * (SERVO_MAX_CCR - SERVO_MIN_CCR)) / 180U;
}

/* ============================================================
 * GPIO
 * ============================================================ */
static void gpio_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN
                 |  RCC_APB2ENR_IOPCEN  | RCC_APB2ENR_AFIOEN;

    /* PORTA CRL */
    GPIOA->CRL =
        (GPIOA->CRL
         & ~(0xFUL<< 0) & ~(0xFUL<< 4) & ~(0xFUL<< 8) & ~(0xFUL<<12)
         & ~(0xFUL<<16) & ~(0xFUL<<20) & ~(0xFUL<<24) & ~(0xFUL<<28))
        | (0x0UL<< 0)   /* PA0 analógico */
        | (0x8UL<< 4)   /* PA1 input pull-up (botón freno) */
        | (0x2UL<< 8)   /* PA2 IN1 trasero */
        | (0x2UL<<12)   /* PA3 IN2 trasero */
        | (0x2UL<<16)   /* PA4 IN3 trasero */
        | (0x2UL<<20)   /* PA5 IN4 trasero */
        | (0x2UL<<24)   /* PA6 ENA trasero */
        | (0x2UL<<28);  /* PA7 ENB trasero */
    GPIOA->ODR |= (1UL<<1);

    /* PORTA CRH */
    GPIOA->CRH =
        (GPIOA->CRH & ~(0xFUL<<0) & ~(0xFUL<<12) & ~(0xFUL<<16))
        | (0x3UL<< 0)   /* PA8  IN1 delantero */
        | (0x3UL<<12)   /* PA11 IN3 delantero */
        | (0x3UL<<16);  /* PA12 IN4 delantero */

    /* JTAG disable → libera PB3, PB4 */
    AFIO->MAPR = (AFIO->MAPR & ~AFIO_MAPR_SWJ_CFG)
               | AFIO_MAPR_SWJ_CFG_JTAGDISABLE;

    /* PORTB CRL */
    GPIOB->CRL =
        (GPIOB->CRL & ~(0xFUL<<12) & ~(0xFUL<<16) & ~(0xFUL<<20))
        | (0x2UL<<12)   /* PB3 IN2 delantero */
        | (0x2UL<<16)   /* PB4 ENA delantero */
        | (0x2UL<<20);  /* PB5 ENB delantero */

    /* PORTB CRH */
    GPIOB->CRH =
        (GPIOB->CRH & ~(0xFUL<<8) & ~(0xFUL<<12))
        | (0x2UL<< 8)   /* PB10 LED3 activo-alto */
        | (0x2UL<<12);  /* PB11 LED4 activo-alto */

    /* PORTC CRH */
    GPIOC->CRH =
        (GPIOC->CRH & ~(0xFUL<<20) & ~(0xFUL<<24))
        | (0x2UL<<20)   /* PC13 LED1 activo-bajo */
        | (0x2UL<<24);  /* PC14 LED2 activo-bajo */

    /* Estado inicial — todo apagado */
    GPIOA->BSRR = (1UL<<(2+16))|(1UL<<(3+16))|(1UL<<(4+16))|(1UL<<(5+16))
                | (1UL<<(6+16))|(1UL<<(7+16))
                | (1UL<<(8+16))|(1UL<<(11+16))|(1UL<<(12+16));
    GPIOB->BSRR = (1UL<<(3+16))|(1UL<<(4+16))|(1UL<<(5+16));
    GPIOC->BSRR = (1UL<<13)|(1UL<<14);
    GPIOB->BSRR = (1UL<<(10+16))|(1UL<<(11+16));
}

/* ============================================================
 * ADC1 — canal 0 (PA0)
 * ============================================================ */
static void adc_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;
    RCC->CFGR = (RCC->CFGR & ~RCC_CFGR_ADCPRE) | RCC_CFGR_ADCPRE_DIV8;
    ADC1->CR2  &= ~ADC_CR2_ADON;
    ADC1->SMPR2 = (0x7UL<<0);
    ADC1->SQR3  = 0U; ADC1->SQR1 = 0U;
    ADC1->CR2  |=  ADC_CR2_ADON;
    delay_us(10);
    ADC1->CR2  |=  ADC_CR2_CAL;
    while (ADC1->CR2 & ADC_CR2_CAL);
}

static uint16_t adc_read(void)
{
    ADC1->CR2 |= ADC_CR2_ADON;
    while (!(ADC1->SR & ADC_SR_EOC));
    return (uint16_t)(ADC1->DR & 0x0FFFU);
}

/* ============================================================
 * MOTORES
 *   motors_forward(pct): pct=0-100, controla duty directo
 *   motors_stop(): frena dinámicamente
 * ============================================================ */
static void motors_forward(uint8_t pct)
{
    if (pct > 100U) pct = 100U;

    /* Dirección adelante — una sola escritura por puerto */
    GPIOA->BSRR = (1UL<<8)         /* PA8  SET IN1 delantero=H */
                | (1UL<<11)        /* PA11 SET IN3 delantero=H */
                | (1UL<<(12+16))   /* PA12 RST IN4 delantero=L */
                | (1UL<<2)         /* PA2  SET IN1 trasero=H   */
                | (1UL<<(3+16))    /* PA3  RST IN2 trasero=L   */
                | (1UL<<4)         /* PA4  SET IN3 trasero=H   */
                | (1UL<<(5+16));   /* PA5  RST IN4 trasero=L   */

    GPIOB->BSRR = (1UL<<(3+16));  /* PB3 RST IN2 delantero=L */

    /* Duty: mapeo pct[1..100] → ticks[MOTOR_DUTY_MIN_TICKS..MOTOR_PWM_PERIOD] */
    uint32_t d_fwd = (uint32_t)MOTOR_DUTY_MIN_TICKS
                   + ((uint32_t)pct * (MOTOR_PWM_PERIOD - MOTOR_DUTY_MIN_TICKS)) / 100U;
    if (d_fwd > MOTOR_PWM_PERIOD) d_fwd = MOTOR_PWM_PERIOD;

    uint32_t d_rear = (uint32_t)((float)d_fwd * REAR_GEAR_RATIO);
    if (d_rear > MOTOR_PWM_PERIOD) d_rear = MOTOR_PWM_PERIOD;

    pwm_fwd  = (uint8_t)d_fwd;
    pwm_rear = (uint8_t)d_rear;
}

static void motors_stop(void)
{
    pwm_fwd  = 0U;
    pwm_rear = 0U;
    GPIOB->BSRR = (1UL<<(4+16))|(1UL<<(5+16));
    GPIOA->BSRR = (1UL<<(6+16))|(1UL<<(7+16));
    GPIOA->BSRR = (1UL<<(8+16))|(1UL<<(11+16))|(1UL<<(12+16))
                | (1UL<<(2+16))|(1UL<<(3+16))|(1UL<<(4+16))|(1UL<<(5+16));
    GPIOB->BSRR = (1UL<<(3+16));
}

/* ============================================================
 * LEDs
 * ============================================================ */
static void led_update(uint16_t v)
{
    if (v > 120U) v = 120U;
    if (v >= 30U)  GPIOC->BSRR=(1UL<<(13+16)); else GPIOC->BSRR=(1UL<<13);
    if (v >= 60U)  GPIOC->BSRR=(1UL<<(14+16)); else GPIOC->BSRR=(1UL<<14);
    if (v >= 90U)  GPIOB->BSRR=(1UL<<10);      else GPIOB->BSRR=(1UL<<(10+16));
    if (v >= 120U) GPIOB->BSRR=(1UL<<11);      else GPIOB->BSRR=(1UL<<(11+16));
}

/* ============================================================
 * PARSER DE COMANDOS USART
 *
 *  Globales (cualquier modo):
 *    MODE:M  → Modo Manual
 *    MODE:I  → Modo Instrucciones
 *
 *  Solo Modo Instrucciones:
 *    A:XXX   → aceleración 0-100
 *    B:X     → freno 0/1
 *    S1:XXX  → Servo1 cámara pan  0-180°
 *    S2:XXX  → Servo2             0-180°
 *    S3:XXX  → Servo3 cámara tilt 0-150°
 * ============================================================ */
static void parse_command(const char *cmd)
{
    if (strncmp(cmd,"MODE:M",6)==0){ op_mode=MODE_MANUAL;        return; }
    if (strncmp(cmd,"MODE:I",6)==0){ op_mode=MODE_INSTRUCCIONES; return; }
    if (op_mode!=MODE_INSTRUCCIONES) return;

    const char *sep = strchr(cmd,':');
    if (!sep) return;
    int val = atoi(sep+1);

    if      (strncmp(cmd,"A:", 2)==0)
    {
        if (val < 0)   val = 0;
        if (val > 100) val = 100;
        accel_virtual = (double)val;
    }
    else if (strncmp(cmd,"B:", 2)==0) { brake_cmd = (val!=0)?1U:0U; }
    else if (strncmp(cmd,"S1:",3)==0)
    {
        if (val < 0)   val = 0;
        if (val > 180) val = 180;
        servo1_deg = (uint16_t)val;
    }
    else if (strncmp(cmd,"S2:",3)==0)
    {
        if (val < 0)   val = 0;
        if (val > 180) val = 180;
        servo2_deg = (uint16_t)val;
    }
    else if (strncmp(cmd,"S3:",3)==0)
    {
        if (val < 0)   val = 0;
        if (val > 150) val = 150;   /* límite S3 = 150° */
        servo3_deg = (uint16_t)val;
    }
}

/* ============================================================
 * TAREA: tModel  P3  40 ms
 *
 *   MODO MANUAL:
 *     Lee potenciómetro → alimenta el modelo SOLO para telemetría.
 *     El modelo NO controla motores ni servos.
 *     Botón freno → reduce pwm_manual progresivamente a 0
 *     en máximo 3 s (75 ticks de 40 ms).
 *     Paso por tick = accel_actual / 75
 *
 *   MODO INSTRUCCIONES:
 *     Recibe A:/B:/S1:/S2:/S3: por USART.
 *     Modelo usa accel_virtual como throttle.
 *     Servos se mueven según comandos.
 * ============================================================ */
static void task_model(void *arg)
{
    (void)arg;
    TickType_t xLastWake  = xTaskGetTickCount();
    uint8_t    zero_ticks = 0U;

    /* pwm_manual: duty actual de motores en modo manual (0-100) */
    static float pwm_manual = 0.0f;

    for (;;)
    {
        vTaskDelayUntil(&xLastWake, pdMS_TO_TICKS(40));

        OpMode_t mode  = op_mode;
        uint8_t  brake = 0U;

        if (mode == MODE_MANUAL)
        {
            uint16_t raw   = adc_read();
            /* ADC 0-4095 → accel 0-100 para el modelo */
            uint16_t accel = (uint16_t)(((uint32_t)raw * 100UL) / 4095UL);
            brake = (GPIOA->IDR & (1UL<<1)) ? 0U : 1U;

            if (brake)
            {
                /* Freno: bajar pwm_manual de accel_actual a 0
                 * en máximo 3 s = 75 ticks.
                 * Paso = accel_actual / 75
                 * Con accel=100: baja 1.33 por tick → 75 ticks = 3 s
                 * Con accel=50:  baja 0.67 por tick → 75 ticks = 3 s
                 * Siempre tarda exactamente 3 s sin importar la velocidad.
                 */
                float step = pwm_manual / 75.0f;
                if (step < 0.5f) step = 0.5f;   /* mínimo para que termine */
                pwm_manual -= step;
                if (pwm_manual < 0.0f) pwm_manual = 0.0f;
            }
            else
            {
                /* Sin freno: pwm_manual sigue el potenciómetro directamente */
                pwm_manual = (float)accel;
            }

            /* Alimentar modelo con la aceleración del potenciómetro
             * solo para generar datos de telemetría */
            accel_virtual = (accel < 2U) ? 2.0 : (double)accel;

            /* Oscilación automática de servos S1 y S3 en modo manual */
            static int16_t  s1_dir = 1;
            static int16_t  s3_dir = 1;
            static uint8_t  servo_tick = 0U;

            /* Mover servos cada 2 ticks = cada 80 ms */
            if (++servo_tick >= 2U)
            {
                servo_tick = 0U;

                /* S1: 0-180°, paso 2° por movimiento */
                int16_t s1 = (int16_t)servo1_deg + s1_dir * 2;
                if (s1 >= 180) { s1 = 180; s1_dir = -1; }
                if (s1 <= 0)   { s1 = 0;   s1_dir =  1; }
                servo1_deg = (uint16_t)s1;

                /* S3: 0-150°, paso 2° por movimiento */
                int16_t s3 = (int16_t)servo3_deg + s3_dir * 2;
                if (s3 >= 150) { s3 = 150; s3_dir = -1; }
                if (s3 <= 0)   { s3 = 0;   s3_dir =  1; }
                servo3_deg = (uint16_t)s3;

                /* Actualizar timers de servos */
                TIM3->CCR3 = deg_to_ccr(servo1_deg);
                TIM4->CCR4 = deg_to_ccr(servo3_deg);
            }
        }
        else
        {
            /* Modo instrucciones */
            brake = brake_cmd;
            if (brake)
            {
                accel_virtual -= BRAKE_RAMP_STEP;
                if (accel_virtual < 2.0) accel_virtual = 2.0;
            }
            /* Servos controlados por comandos */
            TIM3->CCR3 = deg_to_ccr(servo1_deg);
            TIM3->CCR4 = deg_to_ccr(servo2_deg);
            TIM4->CCR4 = deg_to_ccr(servo3_deg);

            pwm_manual = (float)accel_virtual;
        }

        double av = accel_virtual;

        /* Protección idle del modelo */
        if (av <= 2.0) { zero_ticks++; } else { zero_ticks = 0U; }

        if (zero_ticks >= 25U)
        {
            zero_ticks = 0U;
            xSemaphoreTake(xMutexModel, portMAX_DELAY);
            EngTrModel_terminate();
            EngTrModel_initialize();
            xSemaphoreGive(xMutexModel);
            ModelState_t st = {800U,0U,1U,0U,brake,(uint8_t)mode,0U,0U};
            xQueueOverwrite(xQueueModel, &st);
            continue;
        }

        /* Sanity check */
        if (EngTrModel_Y.EngineSpeed  > 8000.0 ||
            EngTrModel_Y.EngineSpeed  < 0.0    ||
            EngTrModel_Y.VehicleSpeed < 0.0    ||
            EngTrModel_Y.VehicleSpeed > 300.0)
        {
            xSemaphoreTake(xMutexModel, portMAX_DELAY);
            EngTrModel_terminate();
            EngTrModel_initialize();
            xSemaphoreGive(xMutexModel);
            zero_ticks = 0U;
            ModelState_t st = {800U,0U,1U,0U,brake,(uint8_t)mode,0U,0U};
            xQueueOverwrite(xQueueModel, &st);
            continue;
        }

        /* Step del modelo */
        EngTrModel_U.Throttle    = av;
        EngTrModel_U.BrakeTorque = brake ? 200.0 : 0.0;
        EngTrModel_step();

        /* Leer salidas */
        double spd = EngTrModel_Y.VehicleSpeed;
        if (spd > (double)VSPEED_MAX_KMH) spd = (double)VSPEED_MAX_KMH;

        uint16_t rpm    = (uint16_t)EngTrModel_Y.EngineSpeed;
        uint16_t vspeed = (uint16_t)spd;
        uint8_t  gear   = (uint8_t)EngTrModel_Y.Gear;
        if (gear < 1U) gear = 1U;
        if (gear > 4U) gear = 4U;

        /* PWM para telemetría */
        uint8_t pct = (uint8_t)pwm_manual;
        uint8_t pwm_fwd_pct  = 0U;
        uint8_t pwm_rear_pct = 0U;
        if (pct > 0U)
        {
            uint32_t d = (uint32_t)MOTOR_DUTY_MIN_TICKS
                       + ((uint32_t)pct * (MOTOR_PWM_PERIOD - MOTOR_DUTY_MIN_TICKS)) / 100U;
            if (d > MOTOR_PWM_PERIOD) d = MOTOR_PWM_PERIOD;
            pwm_fwd_pct = (uint8_t)(d * 100U / MOTOR_PWM_PERIOD);
            uint32_t dr = (uint32_t)((float)d * REAR_GEAR_RATIO);
            if (dr > MOTOR_PWM_PERIOD) dr = MOTOR_PWM_PERIOD;
            pwm_rear_pct = (uint8_t)(dr * 100U / MOTOR_PWM_PERIOD);
        }

        ModelState_t st = {
            rpm, vspeed, gear, (uint16_t)av,
            brake, (uint8_t)mode,
            pwm_fwd_pct, pwm_rear_pct
        };
        xQueueOverwrite(xQueueModel, &st);
    }
}

/* ============================================================
 * TAREA: tMotores  P4  40 ms
 *
 *   MODO MANUAL:  ADC → PWM directo via pwm_manual de tModel.
 *   MODO INSTRUC: modelo → PWM via ModelState.
 * ============================================================ */
static void task_motores(void *arg)
{
    (void)arg;
    ModelState_t st;
    TickType_t xLastWake = xTaskGetTickCount();

    for (;;)
    {
        vTaskDelayUntil(&xLastWake, pdMS_TO_TICKS(40));

        if (op_mode == MODE_MANUAL)
        {
            /* Leer último estado para obtener pwm_fwd_pct calculado por tModel */
            if (xQueuePeek(xQueueModel, &st, 0) == pdTRUE)
            {
                if (st.pwm_fwd_pct == 0U)
                {
                    motors_stop();
                    led_update(0U);
                }
                else
                {
                    motors_forward(st.pwm_fwd_pct);
                    led_update((uint16_t)((uint32_t)st.pwm_fwd_pct
                               * VSPEED_MAX_KMH / 100U));
                }
            }
        }
        else
        {
            if (xQueuePeek(xQueueModel, &st, 0) == pdTRUE)
            {
                if (st.pwm_fwd_pct == 0U)
                    motors_stop();
                else
                    motors_forward(st.pwm_fwd_pct);

                led_update(st.vspeed);
            }
        }
    }
}

/* ============================================================
 * TAREA: tDisplay  P1  200 ms
 * ============================================================ */
static void task_display(void *arg)
{
    (void)arg;
    ModelState_t st = {800U,0U,1U,2U,0U,0U,0U,0U};
    TickType_t xLastWake = xTaskGetTickCount();

    for (;;)
    {
        vTaskDelayUntil(&xLastWake, pdMS_TO_TICKS(200));
        xQueuePeek(xQueueModel, &st, 0);

        LCD_SetCursor(1,1);
        LCD_PutStr("A:");
        LCD_PutUInt(st.accel_pct, 3);
        LCD_PutChar('%');
        LCD_PutChar(st.mode==MODE_MANUAL?'M':'I');
        LCD_PutStr(" R:");
        LCD_PutUInt(st.rpm, 4);
        LCD_PutChar(' ');

        LCD_SetCursor(2,1);
        if (st.brake) {
            LCD_PutStr("***FRENO*** M:");
            LCD_PutChar((char)('0'+st.gear));
            LCD_PutChar(' ');
        } else {
            LCD_PutStr("V:");
            LCD_PutUInt(st.vspeed, 3);
            LCD_PutStr("km/h M:");
            LCD_PutChar((char)('0'+st.gear));
            LCD_PutStr("  ");
        }
    }
}

/* ============================================================
 * TAREA: tComms  P2  40 ms
 *
 *  Recibe comandos USART y envía telemetría JSON.
 *
 *  JSON enviado cada 40 ms:
 *  {"m":X,"a":XXX,"b":X,"r":XXXXX,"v":XXX,"g":X,
 *   "pf":XXX,"pt":XXX,"s1":XXX,"s2":XXX,"s3":XXX}
 *
 *   m  = modo (0=Manual, 1=Instrucciones)
 *   a  = aceleración % (potenciómetro o comando A:)
 *   b  = freno activo (0/1)
 *   r  = RPM motor (del modelo)
 *   v  = velocidad km/h (del modelo, 0-120)
 *   g  = marcha (1-4, del modelo)
 *   pf = PWM delantero % efectivo
 *   pt = PWM trasero % efectivo
 *   s1 = ángulo Servo1 cámara pan (0-180°)
 *   s2 = ángulo Servo2 (0-180°)
 *   s3 = ángulo Servo3 cámara tilt (0-150°)
 * ============================================================ */
static void task_comms(void *arg)
{
    (void)arg;
    ModelState_t st = {800U,0U,1U,2U,0U,0U,0U,0U};
    TickType_t xLastWake = xTaskGetTickCount();

    for (;;)
    {
        vTaskDelayUntil(&xLastWake, pdMS_TO_TICKS(40));

        if (rx_rdy)
        {
            char local[RX_BUF_SIZE];
            __disable_irq();
            memcpy(local,(const void*)rx_buf, RX_BUF_SIZE);
            rx_rdy = 0U;
            __enable_irq();
            parse_command(local);
        }

        xQueuePeek(xQueueModel, &st, 0);

        char buf[128];
        int n = snprintf(buf, sizeof(buf),
            "{\"m\":%u,\"a\":%u,\"b\":%u,\"r\":%u,\"v\":%u,\"g\":%u,"
            "\"pf\":%u,\"pt\":%u,\"s1\":%u,\"s2\":%u,\"s3\":%u}\n",
            (unsigned)st.mode,      (unsigned)st.accel_pct,
            (unsigned)st.brake,     (unsigned)st.rpm,
            (unsigned)st.vspeed,    (unsigned)st.gear,
            (unsigned)st.pwm_fwd_pct, (unsigned)st.pwm_rear_pct,
            (unsigned)servo1_deg,   (unsigned)servo2_deg,
            (unsigned)servo3_deg);
        if (n > 0 && n < (int)sizeof(buf))
            usart1_send_str(buf);
    }
}

/* ============================================================
 * MAIN
 * ============================================================ */
int main(void)
{
    rcc_init_64MHz();
    gpio_init();
    adc_init();
    usart1_init();
    tim3_servo_init();
    tim4_servo_init();
    LCD_Init();
    tim2_pwm_init();

    rt_InitInfAndNaN(sizeof(real_T));
    EngTrModel_initialize();

    LCD_SetCursor(1,1); LCD_PutStr(" TRACTOR RC v5  ");
    LCD_SetCursor(2,1); LCD_PutStr(" Modo: MANUAL   ");
    delay_ms(1500);
    LCD_Clear();
    delay_ms(5);

    xQueueModel  = xQueueCreate(1, sizeof(ModelState_t));
    xMutexModel  = xSemaphoreCreateMutex();
    configASSERT(xQueueModel);
    configASSERT(xMutexModel);

    xTaskCreate(task_model,   "tModel",   512, NULL, 3, NULL);
    xTaskCreate(task_motores, "tMotores", 128, NULL, 4, NULL);
    xTaskCreate(task_display, "tDisplay", 256, NULL, 1, NULL);
    xTaskCreate(task_comms,   "tComms",   256, NULL, 2, NULL);

    vTaskStartScheduler();
    for (;;);
}
